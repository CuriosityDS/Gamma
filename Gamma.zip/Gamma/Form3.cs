﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.Remoting.Messaging;

namespace Gamma
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string messages = textBox1.Text;
            Send("localhost", 8888, messages);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public void Send(string hostname, int port, string messages)
        {
            byte[] bytes = new byte[1024];
            IPHostEntry ipHost = Dns.GetHostEntry(hostname);
            IPAddress ipAddr = ipHost.AddressList[0];
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, port);
            Socket sock = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            sock.Connect(ipEndPoint);
            byte[] data = Encoding.UTF8.GetBytes(messages);
            int bytesSent = sock.Send(data);
            textBox1.Text = "";
            listBox1.Items.Add(messages);
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
            int bytesRec = sock.Receive(bytes);
            listBox1.Items.Add(Encoding.UTF8.GetString(bytes, 0, bytesRec));
            listBox1.SelectedIndex = listBox1.Items.Count - 1;

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }
    }
}
