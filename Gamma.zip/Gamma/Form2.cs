﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gamma
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        bool flag = true;
        private async void timer1_Tick(object sender, EventArgs e)
        {
            await ChangeName();
            if (flag == true) Communicate("localhost", 8888);
        }
        async Task ChangeName()
        {
                await Task.Delay(2000);
                label1.Text = "Ожидаем ответа от сервера.";
                await Task.Delay(2000);
                label1.Text = "Ожидаем ответа от сервера..";
                await Task.Delay(2000);
                label1.Text = "Ожидаем ответа от сервера...";
                await Task.Delay(2000);
                label1.Text = "Ожидаем ответа от сервера..";
                await Task.Delay(2000);
                label1.Text = "Ожидаем ответа от сервера.";
                await Task.Delay(2000);
        }
        public void Communicate(string hostname, int port)
        {

            try
            {
                IPHostEntry ipHost = Dns.GetHostEntry(hostname);
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, port);
                Socket sock = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                sock.Connect(ipEndPoint);
                Form3 form3 = new Form3();
                form3.Show();
                form3.Location = this.Location;
                this.Visible = false;
                flag = false;
                sock.Close();
            }
            catch { label1.ForeColor = Color.Red; }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }

}

